"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { formatRupiah } from "@/lib/utils";
import { BudgetDashboard } from "@/components/sections/budget/BudgetDashboard";
import { BudgetItem, CostActual } from "@/types/budget";

export default function BudgetPage() {
  const params = useParams();
  const projectId = params.id as string;

  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [costActuals, setCostActuals] = useState<CostActual[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBudget = async () => {
      try {
        const response = await fetch(`/api/projects/${projectId}/budget`);
        const data = await response.json();
        if (data.budgetItems) {
          setBudgetItems(data.budgetItems);
          setCostActuals(data.costActuals || []);
        }
      } catch (error) {
        console.error("Failed to fetch budget:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBudget();
  }, [projectId]);

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="text-muted-foreground animate-pulse">Memuat data anggaran...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">Budget & Cost Control</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Lacak anggaran proyek dan catat setiap pengeluaran di lapangan.
        </p>
      </div>

      <BudgetDashboard
        projectId={projectId}
        budgetItems={budgetItems}
        costActuals={costActuals}
        onActualAdded={(newActual) => {
          setCostActuals((prev) => [newActual, ...prev]);
        }}
      />
    </div>
  );
}
