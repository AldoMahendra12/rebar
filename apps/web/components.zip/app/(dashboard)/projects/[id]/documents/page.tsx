"use client";

import { useState } from "react";
import { MOCK_DOCUMENTS } from "@/lib/mock-project";
import { ProjectDocument } from "@/types/document";
import { FileDown, FileUp, Search, FileText, Image as ImageIcon, File, FileCode } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const CATEGORY_TABS = [
  { id: "all", label: "Semua Dokumen" },
  { id: "drawing", label: "Gambar Kerja" },
  { id: "contract", label: "Kontrak" },
  { id: "photo", label: "Foto Lapangan" },
  { id: "report", label: "Laporan" },
];

export default function DocumentsPage() {
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [documents, setDocuments] = useState<ProjectDocument[]>(MOCK_DOCUMENTS);

  const getFileIcon = (type: string) => {
    switch (type) {
      case "photo": return <ImageIcon className="w-8 h-8 text-blue-500" />;
      case "drawing": return <FileCode className="w-8 h-8 text-orange-500" />;
      case "contract": return <FileText className="w-8 h-8 text-emerald-500" />;
      default: return <File className="w-8 h-8 text-slate-500" />;
    }
  };

  const getCategoryLabel = (type: string) => {
    const tab = CATEGORY_TABS.find(t => t.id === type);
    return tab ? tab.label : "Lainnya";
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Filter docs
  const filteredDocs = documents.filter(doc => {
    const matchesTab = activeTab === "all" || doc.fileType === activeTab;
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const handleUploadMock = () => {
    const newDoc: ProjectDocument = {
      id: `doc-${Date.now()}`,
      projectId: "prj-001",
      name: `Dokumen_Baru_${Math.floor(Math.random() * 1000)}.pdf`,
      fileUrl: "#",
      fileType: activeTab === "all" ? "other" : activeTab as any,
      uploadedBy: "Anda (Admin)",
      createdAt: new Date().toISOString(),
      sizeBytes: Math.floor(Math.random() * 5000000) + 100000,
    };
    setDocuments([newDoc, ...documents]);
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight">Manajemen Dokumen</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Simpan, bagikan, dan kelola semua file proyek secara terpusat.
          </p>
        </div>
        <Button onClick={handleUploadMock}>
          <FileUp className="w-4 h-4 mr-2" />
          Upload Dokumen
        </Button>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar Nav */}
        <div className="w-full md:w-64 space-y-1">
          {CATEGORY_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full text-left px-4 py-2.5 rounded-lg text-sm transition-colors ${
                activeTab === tab.id 
                  ? "bg-primary text-white font-medium shadow-sm" 
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {tab.label}
              {tab.id !== "all" && (
                <span className={`float-right text-xs px-2 py-0.5 rounded-full ${
                  activeTab === tab.id ? "bg-white/20" : "bg-slate-200"
                }`}>
                  {documents.filter(d => d.fileType === tab.id).length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Cari nama file..." 
              className="pl-9 bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="grid gap-3">
            {filteredDocs.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                <File className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500 text-sm">Tidak ada dokumen ditemukan di kategori ini.</p>
              </div>
            ) : (
              filteredDocs.map((doc) => (
                <Card key={doc.id} className="hover:border-primary/40 transition-colors">
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-4 min-w-0">
                      <div className="p-2 bg-slate-50 rounded-lg shrink-0">
                        {getFileIcon(doc.fileType)}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold text-slate-800 text-sm truncate">{doc.name}</p>
                        <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                          <span>{formatBytes(doc.sizeBytes || 0)}</span>
                          <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                          <span>{new Date(doc.createdAt).toLocaleDateString("id-ID")}</span>
                          <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                          <span>Oleh: {doc.uploadedBy}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <Badge variant="secondary" className="hidden md:inline-flex">
                        {getCategoryLabel(doc.fileType)}
                      </Badge>
                      <Button variant="ghost" size="icon" className="text-slate-500 hover:text-primary">
                        <FileDown className="w-5 h-5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
