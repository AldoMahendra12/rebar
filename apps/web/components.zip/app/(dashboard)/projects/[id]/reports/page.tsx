"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { FileText, Printer, FileDown, History } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

export default function ProjectReportsPage() {
  const params = useParams();
  const projectId = params.id as string;
  
  const [reportType, setReportType] = useState("weekly");
  const [period, setPeriod] = useState("Minggu ke-12 (Maret 2025)");

  const handleGenerate = () => {
    // In a real app, this would call an API to generate a PDF, or open a new window
    // with a print-optimized layout. For this mockup, we'll open the preview page.
    window.open(`/print-preview/${projectId}?type=${reportType}&period=${encodeURIComponent(period)}`, "_blank");
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">Generate Laporan Proyek</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Pilih tipe laporan dan periode untuk menghasilkan dokumen PDF yang siap dicetak.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Generator Form */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Parameter Laporan
            </CardTitle>
            <CardDescription>Sesuaikan data yang ingin ditampilkan di laporan</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <Label>Tipe Laporan</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih tipe laporan..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Laporan Mingguan (Weekly Report)</SelectItem>
                  <SelectItem value="monthly">Laporan Bulanan (Monthly Report)</SelectItem>
                  <SelectItem value="executive">Executive Summary (Ringkasan Klien)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label>Periode Cetak</Label>
              <Input 
                value={period} 
                onChange={(e) => setPeriod(e.target.value)} 
                placeholder="Contoh: Minggu ke-12 (Maret 2025)"
              />
              <p className="text-xs text-muted-foreground">Periode ini akan ditampilkan sebagai judul rentang waktu pada dokumen PDF.</p>
            </div>

            <div className="pt-4 border-t border-border flex gap-3">
              <Button onClick={handleGenerate} className="flex-1">
                <Printer className="w-4 h-4 mr-2" />
                Preview & Cetak PDF
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* History / Info */}
        <Card className="bg-secondary/20">
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <History className="w-4 h-4 text-muted-foreground" />
              Riwayat Ekspor
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-sm border-l-2 border-primary pl-3">
                <p className="font-semibold text-foreground">Laporan Mingguan W11</p>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-xs text-muted-foreground">17 Mar 2025</p>
                  <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                    <FileDown className="w-3 h-3 mr-1" /> PDF
                  </Button>
                </div>
              </div>
              <div className="text-sm border-l-2 border-muted pl-3">
                <p className="font-medium text-muted-foreground">Laporan Bulanan Feb</p>
                <div className="flex items-center justify-between mt-1">
                  <p className="text-xs text-muted-foreground">28 Feb 2025</p>
                  <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                    <FileDown className="w-3 h-3 mr-1" /> PDF
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
