"use client";

import { UserPlus, MoreHorizontal, ShieldAlert, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function TeamSettingsPage() {
  const teamMembers = [
    { id: 1, name: "Budi Santoso", email: "budi@rebarconstruct.co.id", role: "Owner / Admin", status: "Active" },
    { id: 2, name: "Andi Saputra", email: "andi.pm@rebarconstruct.co.id", role: "Project Manager", status: "Active" },
    { id: 3, name: "Siti Aminah", email: "siti.admin@rebarconstruct.co.id", role: "Admin Proyek", status: "Invited" },
  ];

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between">
        <div>
          <CardTitle>Anggota Tim</CardTitle>
          <CardDescription>
            Kelola akses tim ke proyek-proyek dalam organisasi Anda.
          </CardDescription>
        </div>
        <Button size="sm">
          <UserPlus className="w-4 h-4 mr-2" />
          Undang Anggota
        </Button>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border border-border">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left">
                <th className="font-medium p-3">Nama Lengkap</th>
                <th className="font-medium p-3">Peran (Role)</th>
                <th className="font-medium p-3">Status</th>
                <th className="font-medium p-3 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {teamMembers.map((member) => (
                <tr key={member.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                  <td className="p-3">
                    <p className="font-medium text-foreground">{member.name}</p>
                    <p className="text-xs text-muted-foreground">{member.email}</p>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center gap-1.5 text-xs font-medium">
                      {member.role.includes("Admin") ? (
                        <ShieldAlert className="w-3.5 h-3.5 text-blue-500" />
                      ) : (
                        <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
                      )}
                      {member.role}
                    </div>
                  </td>
                  <td className="p-3">
                    <Badge variant={member.status === "Active" ? "default" : "secondary"}>
                      {member.status}
                    </Badge>
                  </td>
                  <td className="p-3 text-right">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
