"use client";

import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Minus, ArrowRight } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useNavigationStore } from "@/stores/navigation-store";
import { useRouter } from "next/navigation";
import { ProjectCard as ProjectCardType } from "@/types";

interface ProjectCardProps {
  project: ProjectCardType;
}

export function ProjectCard({ project }: ProjectCardProps) {
  const [hovered, setHovered] = useState(false);
  const { setActiveProject } = useNavigationStore();
  const router = useRouter();

  function handleClick() {
    setActiveProject({
      id: project.id,
      name: project.name,
      code: project.code,
    });
    router.push(`/projects/${project.id}`);
  }

  // Handle mock data missing cases to match the prompt's `null` checks
  const actualProgress = project.status === 'planning' ? null : project.actualProgress;
  const dev = project.status === 'planning' ? null : project.deviation;

  return (
    <motion.div
      className="relative bg-white border border-zinc-200/80 rounded-2xl overflow-hidden cursor-pointer p-4 flex flex-col justify-between w-full gap-3"
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.18 }}
      onHoverStart={() => setHovered(true)}
      onHoverEnd={() => setHovered(false)}
      onClick={handleClick}
      animate={{
        boxShadow: hovered
          ? "0 8px 28px rgba(0,0,0,0.10)"
          : "0 1px 4px rgba(0,0,0,0.05)",
        borderColor: hovered
          ? "hsl(220 13% 82%)"
          : "hsl(220 13% 91%)",
      }}
    >
      {/* Accent gradient top */}
      <div
        className="absolute top-0 left-0 right-0 h-[3px]"
        style={{ background: getAccentColor(project) }}
      />

      {/* TOP: Nama + Status */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h3 className="font-semibold text-base text-foreground leading-snug line-clamp-2" style={{ maxWidth: "calc(100% - 80px)" }}>
            {project.name}
          </h3>
          <p className="text-xs font-mono text-zinc-400 mt-1">
            {project.code}
          </p>
        </div>
        <StatusBadge status={project.status} />
      </div>

      {/* MIDDLE: Angka Besar */}
      <div>
        <div className="flex items-end gap-3">
          <motion.span
            className={cn(
              "font-display text-4xl font-bold tracking-tight leading-none",
              getProgressColor(dev, actualProgress)
            )}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            {actualProgress !== null && !isNaN(actualProgress)
              ? `${actualProgress.toFixed(1)}%`
              : "—"
            }
          </motion.span>

          {dev !== null && !isNaN(dev) && (
            <DeviationBadge deviation={dev} />
          )}
        </div>
        <p className="text-xs text-zinc-400 mt-1.5">
          {actualProgress !== null && !isNaN(actualProgress)
            ? "progress aktual"
            : "belum ada progress"
          }
        </p>
      </div>

      {/* BOTTOM: Footer */}
      <div className="border-t border-zinc-100 pt-2 flex items-center justify-between">
        <p className="text-xs text-zinc-500 truncate">
          <span className="truncate max-w-[120px] inline-block align-bottom">
            {project.clientName}
          </span>
          <span className="text-zinc-300 mx-1.5">·</span>
          <span className="font-medium text-zinc-700">
            {formatRupiah(project.contractValue)}
          </span>
        </p>

        <motion.span
          animate={{ opacity: hovered ? 1 : 0, x: hovered ? 0 : -6 }}
          transition={{ duration: 0.15 }}
          className="text-xs font-medium text-primary flex items-center gap-1 shrink-0 ml-2"
        >
          Buka <ArrowRight size={11} />
        </motion.span>
      </div>
    </motion.div>
  );
}

// ─── Sub Components ───────────────────────────

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { style: string; label: string }> = {
    planning: { style: "bg-zinc-100 text-zinc-500", label: "Perencanaan" },
    active: { style: "bg-blue-50 text-blue-600", label: "Aktif" },
    on_hold: { style: "bg-amber-50 text-amber-600", label: "Ditunda" },
    completed: { style: "bg-emerald-50 text-emerald-600", label: "Selesai" },
  };
  const { style, label } = map[status] ?? map.planning;

  return (
    <span className={cn(
      "shrink-0 rounded-full px-2.5 py-1 text-xs font-medium",
      style
    )}>
      {label}
    </span>
  );
}

function DeviationBadge({ deviation }: { deviation: number }) {
  if (deviation < 0) return (
    <span className="flex items-center gap-1 rounded-full px-2.5 py-1 bg-red-500/10 mb-0.5">
      <TrendingDown size={11} className="text-red-500" />
      <span className="text-xs font-semibold text-red-500">
        {deviation.toFixed(1)}%
      </span>
    </span>
  );

  if (deviation > 0) return (
    <span className="flex items-center gap-1 rounded-full px-2.5 py-1 bg-emerald-500/10 mb-0.5">
      <TrendingUp size={11} className="text-emerald-600" />
      <span className="text-xs font-semibold text-emerald-600">
        +{deviation.toFixed(1)}%
      </span>
    </span>
  );

  return (
    <span className="flex items-center gap-1 rounded-full px-2.5 py-1 bg-blue-500/10 mb-0.5">
      <Minus size={11} className="text-blue-500" />
      <span className="text-xs font-semibold text-blue-500">
        On Track
      </span>
    </span>
  );
}

// ─── Helper Functions ─────────────────────────

function getAccentColor(project: ProjectCardType): string {
  if (project.status === "planning") return "#d4d4d8";
  if (project.status === "on_hold") return "#f59e0b";
  if (project.status === "completed") return "#10b981";
  
  // active — berdasarkan deviation
  const d = project.deviation;
  if (d === null || isNaN(d)) return "#d4d4d8";
  if (d <= -5) return "#ef4444";
  if (d < 0) return "#f97316";
  if (d > 0) return "#10b981";
  return "#3b82f6";
}

function getProgressColor(
  deviation: number | null,
  actual: number | null
): string {
  if (actual === null || isNaN(actual)) return "text-zinc-200";
  if (deviation === null || isNaN(deviation)) return "text-foreground";
  if (deviation <= -5) return "text-red-500";
  if (deviation < 0) return "text-orange-500";
  if (deviation > 0) return "text-emerald-600";
  return "text-foreground";
}

function formatRupiah(value: number): string {
  if (value >= 1_000_000_000_000)
    return `Rp ${(value / 1_000_000_000_000).toFixed(1)}T`;
  if (value >= 1_000_000_000)
    return `Rp ${(value / 1_000_000_000).toFixed(1)}M`;
  if (value >= 1_000_000)
    return `Rp ${(value / 1_000_000).toFixed(1)}Jt`;
  return `Rp ${value.toLocaleString("id-ID")}`;
}
